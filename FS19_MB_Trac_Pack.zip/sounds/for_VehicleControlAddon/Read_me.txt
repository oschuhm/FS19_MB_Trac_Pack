
   German
   ------

F�r VehicleControlAddon (ehemals KeyboardSteer):

Wer mit dem "VehicleControlAddon" manuell schalten m�chte, muss
die Datei "MB_Trac_sounds.xml" aus dem Ordner "sounds" durch die
gleichnamige Datei aus dem Ordner "sound\for_VehicleControlAddon"
ersetzen.

Wer das "VehicleControlAddon" nutzt, aber automatisch schalten
lassen m�chte, muss die Getriebeeinstellung f�r diesen Schlepper
im "VehicleControlAddon" auf "off" stellen.


======================

   English
   -------

For VehicleControlAddon (formerly KeyboardSteer):

Those who want to shift the gear manually with the "VehicleControlAddon"
must copy the file "MB_Trac_sounds.xml" from the folder "for_VehicleControlAddon"
(located in the folder "sounds") to the folder "sounds" to replace the other
"MB_Trac_sounds.xml".

Those who uses the "VehicleControlAddon", but want to shift the gear automatically
must set the Gearbox in "VehicleControlAddon" for this tractor to "off".
